// By: Graham Watson

#include <Fizzle\Fizzle.h>
#include <string>
#include <vector>
#include <map>
#include <iostream>

#include "Character.h"
#include "InputMapper.h"
#include "Sprite.h"

#ifdef WIN32

#define WIN32_LEAN_AND_MEAN

#endif

using std::string;

/*
* Testing the map settings and input mapping.
*/

// The global callback (called first, controls global commands)
void globalCallback(InputMapping::MappedInput& inputs);

// The callback for the main exploration mode
void ExploreCallback(InputMapping::MappedInput& inputs);

// Initializes a vector of available keys
void initValidKeys(std::vector<FzlKey>& validKeys);

// Initializes a map of available keys for hold checking
void initPreviouslyPressed(std::map<FzlKey, bool>& previouslyPressed, const std::vector<FzlKey>& validKeys);

// GLOBAL VARIABLES
Character::Character player;
bool spinning;

int main()
{
	// Window height and width
	const int WINDOW_HEIGHT = 480;
	const int WINDOW_WIDTH = 640;

	// Initialize Fizzle
	FzlInit("Map Test", WINDOW_WIDTH, WINDOW_HEIGHT, 0);

	// Keep track of if the program is finished
	bool done = false;
	spinning = false;

	// Load the assets
	Sprite::Sprite background("../Assets/Zelda.gif", 512, 336);
	Sprite::AnimatedSprite playerSprite("../Assets/penguin.png", 41, 42, 8);

	// Set up the player character
	player = Character::Character(playerSprite);
	player.moveSprite(100, 100);

	// Input Mapper
	InputMapping::InputMapper Mapper;
	Mapper.PushContext(L"maincontext");
	Mapper.AddCallback(ExploreCallback, 1);		// Goes from top to bottom.

	Mapper.PushContext(L"globalContext");
	Mapper.AddCallback(globalCallback, 0);

	// Hold valid keys
	std::vector<FzlKey> validKeys;
	initValidKeys(validKeys);

	// Hold pressed keys
	std::map<FzlKey, bool> previouslyPressed;
	initPreviouslyPressed(previouslyPressed, validKeys);

	while (!done)
	{
		// HANDLE EVENTS

		// Go through all valid keys and set if they are down or not, and if they have been previously down.
		for (FzlKey key : validKeys)
		{
			if (FzlGetKey(key))
			{
				bool previouslyDown = previouslyPressed[key];
				previouslyPressed[key] = true;
				Mapper.SetRawButtonState(key, true, previouslyDown);
			}
			else
			{
				previouslyPressed[key] = false;
				Mapper.SetRawButtonState(key, false, true);
			}
		}

		// Distribute the current keypresses to all the available contexts,
		// Then clear the mapper.
		Mapper.Dispatch();
		Mapper.Clear();

		// UPDATE
		player.update();

		// DRAW
		background.draw();
		player.draw();
		FzlSwapBuffers();
	}

	// DESTROY EVERYTHING
	FzlDestroy();
	return 0;
}

void globalCallback(InputMapping::MappedInput& inputs)
{
	if (inputs.Actions.find(InputMapping::EXIT_GAME) != inputs.Actions.end())
	{
		FzlDestroy();
		exit(1);
	}
}

void ExploreCallback(InputMapping::MappedInput& inputs)
{
	// Wheeeeee! Check if the MOVE_DOWN state is on, and if so spin the character
	spinning = inputs.States.find(InputMapping::MOVE_DOWN) != inputs.States.end();
	if (spinning)
	{
		player.rotateSprite(2.0);
	}

	// If the ATTACK action is available..
	if (inputs.Actions.find(InputMapping::ATTACK) != inputs.Actions.end())
	{
		std::cout << "Attack!" << std::endl;
	}

	// If the EXIT_GAME action is available..
	if (inputs.Actions.find(InputMapping::EXIT_GAME) != inputs.Actions.end())
	{
		std::cout << "Didn't work!" << std::endl;
	}

}

void initValidKeys(std::vector<FzlKey>& validKeys)
{
	validKeys.push_back(FzlKeyA);
	validKeys.push_back(FzlKeyW);
	validKeys.push_back(FzlKeyD);
	validKeys.push_back(FzlKeyS);
	validKeys.push_back(FzlKeySpace);
	validKeys.push_back(FzlKeyEscape);
}

void initPreviouslyPressed(std::map<FzlKey, bool>& previouslyPressed, const std::vector<FzlKey>& validKeys)
{
	for (FzlKey key : validKeys)
	{
		previouslyPressed[key] = false;
	}
}


