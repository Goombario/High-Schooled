#ifndef RAW_INPUT_CONSTANTS_H
#define RAW_INPUT_CONSTANTS_H

namespace InputMapping
{

	enum RawInputAxis
	{
		RAW_INPUT_AXIS_MOUSE_X,
		RAW_INPUT_AXIS_MOUSE_Y,
	};

}

#endif